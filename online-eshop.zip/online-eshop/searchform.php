<?php
/**
 * Displays the searchform
 *
 * @package Online Eshop
 * @since 1.0
 */
?>
<form action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get" role="search">
	<input type="search" name="s" placeholder="<?php _e('Search here', 'online-eshop'); ?>" autocomplete="off" />
	<button type="submit"><i class="fa fa-search"></i></button>
</form> <!-- end .search-form -->