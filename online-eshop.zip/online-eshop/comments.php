<?php
/**
 * The template for displaying comments
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Online Eshop
 * @since 1.0
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
*/
if ( post_password_required() ) {
	return;
} ?>
<?php if ( have_comments() ) : ?>
<div class="comments-area floatleft">
	<div class="comments-heading">
		<h2><?php $comments_number = get_comments_number(); printf(_nx('Comment <span>(%1$s)</span>', 'Comments <span>(%1$s)</span>', $comments_number, 'Comments', 'online-eshop' ), number_format_i18n( $comments_number ), get_the_title() ); ?></h2>
	</div><!-- .comments-heading -->

	<?php
	// Show comment form at top if showing newest comments at the top.
	if ( comments_open() ) {
		online_eshop_comment_form( 'desc' );
	}
	?>
	<div class="comments-list">
		<?php
		wp_list_comments(
			array(
				'walker'      => new Online_Eshop_Walker_Comment(),
				'avatar_size' => online_eshop_get_avatar_size(),
				'short_ping'  => true,
				'style'       => 'div',
			)
		);
		?>
	</div><!-- .comment-list -->
</div>
<?php endif; // if have_comments();	?>

<?php

$req = get_option( 'require_name_email' );
$aria_req = ( $req ? " aria-required='true'" : '' );

$fields = array(
    'author' => '<fieldset><div class="row"><div class="col-sm-6 feld"><input id="author" name="author" type="text" placeholder="'. __( 'Full Name *', 'online-eshop' ). '" value="' . esc_attr( $commenter['comment_author'] ) . '" required="required"><span><i class="fa fa-user"></i></span></div>',
    'email' => '<div class="col-sm-6 feld"><input id="email" name="email" type="text" placeholder="'. __( 'Email *', 'online-eshop' ). '" value="' . esc_attr( $commenter['comment_author_email'] ) . '" required="required"><span><i class="fa fa-envelope"></i></span></div></div></fieldset>'
);

$comments_args = array
(
	'class_form' => '',
	'submit_button' => '<div class="btn-area"><button class="btn1" type="submit" id="%2$s">'.esc_html__( 'Post Comment', 'online-eshop').'</button></div>',
	'title_reply' => '<div class="form-heading"><h2>'.esc_html__( 'Get In Touch', 'online-eshop' ).'</h2></div>',
	'fields' => apply_filters( 'comment_form_default_fields', $fields ),
	'comment_field' => '<fieldset><div class="feld"><textarea name="comment" placeholder="' . __( 'Comment here *', 'online-eshop' ) . '" class="p-textarea" aria-required="true" '. $aria_req . '>' .
		'</textarea><span class="msg"><i class="fa fa-pencil-square-o"></i></span></div></fieldset>',
);

// Show comment form at bottom if showing newest comments at the bottom.
if ( comments_open() && 'asc' === strtolower( get_option( 'comment_order', 'asc' ) ) ) : ?>
	<div class="form-area floatleft">
		<?php comment_form($comments_args);; ?>
	</div>
	<?php
endif;
?>